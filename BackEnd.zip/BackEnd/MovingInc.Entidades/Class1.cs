﻿using System;

namespace MovingInc.Entidades
{
    public class Class1
    {
    }
}
